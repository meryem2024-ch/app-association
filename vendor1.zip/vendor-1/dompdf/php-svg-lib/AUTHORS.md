SvgLib was designed and developed by Fabien Ménager.

### Current Team

* **Brian Sweeney** (maintainer)

### Alumni

* **Fabien Ménager** (creator)

### Contributors
* **ssddanbrown**
* [and many more...](https://github.com/dompdf/php-svg-lib/graphs/contributors)

### Thanks

SvgLib would not have been possible without strong community support.